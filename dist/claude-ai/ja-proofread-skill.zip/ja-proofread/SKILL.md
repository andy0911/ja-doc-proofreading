---
name: ja-proofread
description: プロジェクトの指示で日本語の文書の校正を頼まれているとき、または本人が日本語の文書の校正を頼んだとき（「校正して」「AIっぽさを消して」「読みやすいか見て」「出す前に見て」など）に使う。文書をファイルに保存し、textlint と「AIの文章に出やすい型」の台帳で機械チェックして、「必ず直す」の指摘を直してから渡す。依存を入れるのに数十秒かかるので、頼まれていない会話では使わない。
---

# 日本語の文書の校正（ja-proofread v0.1.16、claude.ai のチャット向け）

このスキルのフォルダ（この SKILL.md があるフォルダ）に、校正のスクリプト（`scripts/`）、台帳と表記の辞書（`data/`）、手順の本文（`references/`）があります。下と references/ では、このフォルダを `$D` と書きます。スキルのフォルダには書き込みません（書けないことがあるため）。依存と記録は、書き込める場所（`~/.cache/ja-proofread`、書けなければ一時ディレクトリの下）にスクリプトが置きます。環境変数 `JA_PROOFREAD_DATA` は付けません。

## 毎回の校正（日本語の文書を書いた・直したら）

1. スキルのフォルダを決め、Node が動くか確かめます。次を、そのまま実行します。
   ```bash
   V="0.1.16"; D="${CLAUDE_SKILL_DIR}"
   ok() { [ -f "$1/scripts/proofread.mjs" ] && grep -q '"name": "ja-proofread-claude-ai"' "$1/skill.json" 2>/dev/null && grep -q "\"version\": \"$V\"" "$1/skill.json"; }
   if [ -z "$D" ]; then
     C=$(for d in /mnt/skills/*/ja-proofread /mnt/skills/ja-proofread "$HOME/.claude/skills/ja-proofread"; do ok "$d" && (cd "$d" && pwd -P); done | sort -u)
     [ -n "$C" ] || C=$(find / \( -path /proc -o -path /sys -o -path /dev \) -prune -o -path '*/ja-proofread/skill.json' -print 2>/dev/null | while read -r f; do d=$(dirname "$f"); ok "$d" && (cd "$d" && pwd -P); done | sort -u)
     N=$(printf '%s\n' "$C" | grep -c .)
     if [ "$N" -eq 1 ]; then D="$C"; elif [ "$N" -gt 1 ]; then echo "ja-proofread のスキルのフォルダの候補が $N 件です:"; printf '%s\n' "$C"; fi
   fi
   if [ -n "$D" ] && ok "$D"; then echo "D=$D"; node -v; else echo "ja-proofread（v$V）のスキルのフォルダを決められませんでした"; fi
   ```
   `D=…` の行が出たら、そのパスがスキルのフォルダです。一度決めた D は、同じ会話の中で使い回し、1をもう一度実行しません。下のコマンドの `$D` は、毎回、先頭に `D="<そのパス>";` を付けて実行します（コマンドごとにシェルが変わっても動くように）。
   - 「候補が N 件です」と出たら（2件以上）、どれも使わずに止め、表示されたパスを本人に見せて、どれを使うか尋ねます。
   - 「決められませんでした」と出たら、スキルが見つからないので、校正したことにせず、校正できなかったと伝えます。
   - `node -v` が失敗したときは、下の「コード実行や Node が使えないとき」に従います。
2. 書いた文書を、作業用のファイル（例：`/tmp/ja-proofread-work/文書.md`）に Markdown で保存します。アーティファクトや返答で渡す文書は、その本文を保存します。スライドは、1枚を `## 番号 見出し` の節にして書き出します。
3. 依存を入れてから校正します。依存は会話の最初だけ数十秒かかります。スライドや体言止めの多い資料は、`--profile slide` をファイルの前に付けます。
   ```bash
   D="<1のパス>"; node "$D/scripts/ensure-deps.mjs" && node "$D/scripts/proofread.mjs" /tmp/ja-proofread-work/文書.md
   ```
4. 「必ず」の指摘を直し、元の文書（アーティファクト・ファイル・返答）にも同じ直しを入れて、3の proofread をもう一度実行します。誤検知と判断したもの以外の「必ず」が0件になってから渡します。誤検知と判断したものは直さず、渡すときにそう書きます。「直したい」は文脈を見て直します。
5. 渡すときに、校正の件数（必ず・直したい・参考、直す前 → 直した後）を1行で伝えます。

「textlint が動かなかった」と出たら、表記と文法の指摘は確かめられていないと伝えます。

## コード実行や Node が使えないとき、依存が入らないとき

- Node はあるが依存が入らない（npm が無い、registry.npmjs.org に届かない）：proofread.mjs はそのまま動き、構成の型と件数で数える型だけを点検します。件数を伝えるときに、textlint は動かなかったと書きます。
- コード実行や Node が使えない：校正はできません。校正したとは書かず、校正できなかった（textlint もスクリプトも動かなかった）と伝えます。代わりに、`$D/data/ledger.json`（台帳の型）と `$D/data/prh.yml`（表記の辞書）を読んで文書を点検してもかまいませんが、それは「目で見た点検」として伝え、校正の件数は書きません。

## 書く前（新しく書くとき）

`$D/references/write.md` を読み、その手順（台帳の型を避けて書く）に従います。

## 仕上げ（「校正して」「出す前に見て」と頼まれたときだけ）

`$D/references/proofread.md` の手順に従います。チャットではサブエージェントを使えないので、構成の型の点検（独立レビュー）と読者役テストは、同じ会話の中で、`$D/references/agents/` の役の指示に従って行います。書いた本人と同じ会話なので、独立性は低くなります。本人には「対象の文書と役の指示を別の会話に貼って読ませると、独立性が上がる」と伝えます。

## 新しい型の候補と誤検知

`$D/references/grow-ledger.md` の手順に従います。新しい型の候補を Notion の候補一覧（Notion のコネクタ）に登録するのは、本人が頼んだときだけです。台帳のファイル（`data/`）は書き換えません。

## 記録

検出と誤検知の記録は `~/.cache/ja-proofread`（書けなければ一時ディレクトリの下の、自分だけが使える `ja-proofread-cache-<uid>`）に残ります。会話をまたいで残るかは分からないので、残らない前提で使います。
